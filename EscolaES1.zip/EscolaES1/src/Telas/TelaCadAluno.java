/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Telas;

/**
 *
 * @author ArtPc
 */
import java.sql.*;
import Conexao.ModuloConexao;
import javax.swing.JOptionPane;

public class TelaCadAluno extends javax.swing.JInternalFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public TelaCadAluno() {
        initComponents();
        conexao = ModuloConexao.conector();
    }

    //consulta aluno
    private void consultar() {
        String sql = "select * from pessoa where matricula=?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtAlunoMatricula.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                txtAlunoUsuario.setText(rs.getString(2));
                txtAlunoSenha.setText(rs.getString(3));
                txtAlunoTipo.setText(rs.getString(4));
                txtAlunoNome.setText(rs.getString(5));
                txtAlunoDataNasc.setText(rs.getString(6));
                txtAlunoTel.setText(rs.getString(7));
                txtAlunoNumero.setText(rs.getString(8));
                txtAlunoComplemento.setText(rs.getString(9));
                txtAlunoCep.setText(rs.getString(10));
            } else {
                JOptionPane.showMessageDialog(null, "Usuario não Cadastrado");
                txtAlunoUsuario.setText(null);
                txtAlunoSenha.setText(null);
                txtAlunoTipo.setText("Aluno");
                txtAlunoNome.setText(null);
                txtAlunoDataNasc.setText(null);
                txtAlunoTel.setText(null);
                txtAlunoNumero.setText(null);
                txtAlunoComplemento.setText(null);
                txtAlunoCep.setText(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //adiciona aluno
    private void adicionar() {
        String sql = "insert into pessoa(matricula,usuario,senha,tipo,nome,dataNasc,telefone,numero,complemento,cep) values (?,?,?,?,?,?,?,?,?,?)";
        String sql2 = "insert into aluno(codNotas,matricula,situacao)values(?,?,?)";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtAlunoMatricula.getText());
            pst.setString(2, txtAlunoUsuario.getText());
            pst.setString(3, txtAlunoSenha.getText());
            pst.setString(4, txtAlunoTipo.getText());
            pst.setString(5, txtAlunoNome.getText());
            pst.setString(6, txtAlunoDataNasc.getText());
            pst.setString(7, txtAlunoTel.getText());
            pst.setString(8, txtAlunoNumero.getText());
            pst.setString(9, txtAlunoComplemento.getText());
            pst.setString(10, txtAlunoCep.getText());

            //validação dos campos obrigatórios
            if (!txtAlunoMatricula2.getText().equals(txtAlunoMatricula.getText())) {
                JOptionPane.showMessageDialog(null, "A matrícula está incorreta.");
            } else {
                if ((txtAlunoMatricula.getText().isEmpty()) || (txtAlunoUsuario.getText().isEmpty()) || (txtAlunoSenha.getText().isEmpty()) || (txtAlunoNome.getText().isEmpty()) || (txtAlunoDataNasc.getText().isEmpty()) || (txtAlunoTel.getText().isEmpty()) || (txtAlunoNumero.getText().isEmpty()) || (txtAlunoComplemento.getText().isEmpty()) || (txtAlunoCep.getText().isEmpty())) {
                    JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios.");
                } else {
                    Savepoint ponto1 = conexao.setSavepoint();

                    //executa a query
                    int adicionado = pst.executeUpdate();
                    if (adicionado > 0) {
                        try {
                            pst = conexao.prepareStatement(sql2);
                            pst.setString(2, txtAlunoMatricula2.getText());

                            int adicionado2 = pst.executeUpdate();
                            if (adicionado2 > 0) {
                                JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso.");
                                txtAlunoUsuario.setText(null);
                                txtAlunoSenha.setText(null);
                                txtAlunoTipo.setText("Aluno");
                                txtAlunoNome.setText(null);
                                txtAlunoDataNasc.setText(null);
                                txtAlunoTel.setText(null);
                                txtAlunoNumero.setText(null);
                                txtAlunoComplemento.setText(null);
                                txtAlunoCep.setText(null);
                            }
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, e);
                            conexao.rollback(ponto1);//retorna ao save point e desfaz a primeira inserção
                        }
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtAlunoMatricula = new javax.swing.JTextField();
        txtAlunoUsuario = new javax.swing.JTextField();
        txtAlunoTipo = new javax.swing.JTextField();
        txtAlunoDataNasc = new javax.swing.JTextField();
        txtAlunoNome = new javax.swing.JTextField();
        txtAlunoTel = new javax.swing.JTextField();
        txtAlunoCep = new javax.swing.JTextField();
        txtAlunoNumero = new javax.swing.JTextField();
        txtAlunoComplemento = new javax.swing.JTextField();
        btnAlunoCreate = new javax.swing.JButton();
        btnAlunoDelete = new javax.swing.JButton();
        btnAlunoUpdate = new javax.swing.JButton();
        btnAlunoRead = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtAlunoMatricula2 = new javax.swing.JTextField();
        txtAlunoSenha = new javax.swing.JPasswordField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Alunos");
        setPreferredSize(new java.awt.Dimension(640, 538));

        jLabel1.setText("* Matrícula:");

        jLabel2.setText("* Usuário:");

        jLabel3.setText("* Senha:");

        jLabel4.setText(" Tipo:");

        jLabel5.setText("* Nome:");

        jLabel6.setText("* Data de Nascimento:");

        jLabel7.setText("* Telefone:");

        jLabel8.setText("* Número:");

        jLabel9.setText("* Complemento:");

        jLabel10.setText("* CEP:");

        txtAlunoTipo.setText("Aluno");
        txtAlunoTipo.setEnabled(false);

        txtAlunoComplemento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAlunoComplementoActionPerformed(evt);
            }
        });

        btnAlunoCreate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/create.png"))); // NOI18N
        btnAlunoCreate.setToolTipText("Adiconar");
        btnAlunoCreate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAlunoCreate.setPreferredSize(new java.awt.Dimension(80, 80));
        btnAlunoCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlunoCreateActionPerformed(evt);
            }
        });

        btnAlunoDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        btnAlunoDelete.setToolTipText("Excluir");
        btnAlunoDelete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        btnAlunoUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/update.png"))); // NOI18N
        btnAlunoUpdate.setToolTipText("Atualizar");
        btnAlunoUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        btnAlunoRead.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/read.png"))); // NOI18N
        btnAlunoRead.setToolTipText("Consultar");
        btnAlunoRead.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAlunoRead.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlunoReadActionPerformed(evt);
            }
        });

        jLabel11.setText("* Campos Obrigatórios");

        jLabel12.setText("* Digite Novamente a Matrícula:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlunoMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel12)
                            .addComponent(txtAlunoMatricula2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txtAlunoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtAlunoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtAlunoDataNasc))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtAlunoTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtAlunoNome, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlunoTel, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlunoComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlunoCep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlunoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(72, 72, 72))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAlunoUpdate)
                                .addGap(18, 18, 18)
                                .addComponent(btnAlunoDelete))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAlunoCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnAlunoRead)))
                        .addGap(20, 20, 20))))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAlunoCreate, btnAlunoDelete, btnAlunoRead, btnAlunoUpdate});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnAlunoRead)
                            .addComponent(btnAlunoCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAlunoUpdate, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnAlunoDelete, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtAlunoMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtAlunoMatricula2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtAlunoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtAlunoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtAlunoTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtAlunoNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtAlunoDataNasc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtAlunoTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtAlunoCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(txtAlunoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtAlunoComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(108, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAlunoCreate, btnAlunoDelete, btnAlunoRead, btnAlunoUpdate});

        setBounds(0, 0, 640, 538);
    }// </editor-fold>//GEN-END:initComponents

    private void txtAlunoComplementoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAlunoComplementoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAlunoComplementoActionPerformed

    private void btnAlunoReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlunoReadActionPerformed
        // chamando o metodo consultar
        consultar();

    }//GEN-LAST:event_btnAlunoReadActionPerformed

    private void btnAlunoCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlunoCreateActionPerformed
        // chamando o metodo adicionar
        adicionar();
    }//GEN-LAST:event_btnAlunoCreateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlunoCreate;
    private javax.swing.JButton btnAlunoDelete;
    private javax.swing.JButton btnAlunoRead;
    private javax.swing.JButton btnAlunoUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtAlunoCep;
    private javax.swing.JTextField txtAlunoComplemento;
    private javax.swing.JTextField txtAlunoDataNasc;
    private javax.swing.JTextField txtAlunoMatricula;
    private javax.swing.JTextField txtAlunoMatricula2;
    private javax.swing.JTextField txtAlunoNome;
    private javax.swing.JTextField txtAlunoNumero;
    private javax.swing.JPasswordField txtAlunoSenha;
    private javax.swing.JTextField txtAlunoTel;
    private javax.swing.JTextField txtAlunoTipo;
    private javax.swing.JTextField txtAlunoUsuario;
    // End of variables declaration//GEN-END:variables
}
