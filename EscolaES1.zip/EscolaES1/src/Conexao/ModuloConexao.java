/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexao;

import java.sql.*;

/**
 *
 * @author ArtPc
 */
public class ModuloConexao {

    //estabele conexao com o banco
    public static Connection conector() {
        java.sql.Connection conexao = null;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/escolaES1?useTimezone=true&serverTimezone=UTC";
        String user = "root";
        String password = "123456";
        
        try{
           Class.forName(driver);
           conexao = DriverManager.getConnection(url, user, password);
           return conexao;
        }catch(Exception e){
            //System.out.println(e);
            
            return null;
        }
    }
}
